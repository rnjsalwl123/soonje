require 'thread'

Thread.new do
    system('rails s -b 0.0.0.0 -p 3000')
end