class HomeController < ApplicationController
  def index2
    if session['user_id'] == nil
      redirect_to '/'
    else
      @q = params['q'].to_s
      @page = params['page'].to_s
      if @page == ''
        @page = '1'
      end
      db = SQLite3::Database.open('./soonje.db')
      if session['power'] == 1
        if @q == ''
          r = db.query('select * from board2')
           #limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
        else
          r = db.query('select * from board2 where user_id = "'+@q+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
        end
      else
        r = db.query('select * from board2 where user_id = "'+session['user_id']+'"')
        #" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      end
      @data = Array.new
      r.each do |i|
        time2 = i[5].split('-')
        time3 = Time.new(time2[0].to_i,time2[1].to_i,time2[2].to_i,0,0,0,"+09:00")-Time.now
        time4 = time3/(60*60*24)
        i << time4.to_i.to_s
        p i
        @data << i
      end
    end
  end
  
  def index2_add
    if session['power'] == 1
      @q = params['q'].to_s
      @page = params['page'].to_s
      if @page == ''
        @page = '1'
      end
      db = SQLite3::Database.open('./soonje.db')
      if @q == ''
        r = db.query('select * from money limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      else
        r = db.query('select * from money where user_id = "'+@q+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      end
      @data = Array.new
      r.each do |i|
        p i
        @data << i
      end
    else
      redirect_to '/'
    end
  end
  
  #슬롯삭제
  def board2_delete
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      db.query('delete from board2 where _id = '+params['id'].to_s)
      redirect_to '/slot_list?q='+params['q']
    else
      redirect_to '/'
    end
  end
  
  #관리자 슬롯 리스트
  def slot_list
    if session['power'] == 1
      @q = params['q'].to_s
      @page = params['page'].to_s
      if @page == ''
        @page = '1'
      end
      db = SQLite3::Database.open('./soonje.db')
      if session['power'] == 1
        if @q == ''
          r = db.query('select * from board2 limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
        else
          r = db.query('select * from board2 where user_id = "'+@q+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
        end
      else
        r = db.query('select * from board2 where user_id = "'+session['user_id']+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      end
      @data = Array.new
      r.each do |i|
        begin
          time2 = i[5].split('-')
          time3 = Time.new(time2[0].to_i,time2[1].to_i,time2[2].to_i,0,0,0,"+09:00")-Time.now
          time4 = time3/(60*60*24)
          i << time4.to_i.to_s
        rescue
        
        end
        p i
        @data << i
      end
    else
      redirect_to '/'
    end
  end
  
  #회원가입 허가요청 리스트
  def user2_list
    if session['power'] == 1
      @q = params['q'].to_s
      @page = params['page'].to_s
      if @page == ''
        @page = '1'
      end
      db = SQLite3::Database.open('./soonje.db')
      @data = db.query('select * from user3 where power = -1 limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
    else
      redirect_to '/'
    end
  end
  
  def user2_list_action
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      db.query('update user3 set power = 2 where _id = '+params['id'].to_s)
      redirect_to '/user2_list'
    else
      redirect_to '/'
    end
  end
  
  #유저리스트
  def user_list
    if session['power'] == 1
      @q = params['q'].to_s
      @page = params['page'].to_s
      if @page == ''
        @page = '1'
      end
      db = SQLite3::Database.open('./soonje.db')
      @data = db.query('select * from user3 where power = 2 limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
    else
      redirect_to '/'
    end
  end
  
  #승인 허가
  def index2_add_action
    begin
      db = SQLite3::Database.open('./soonje.db')
      counter = params['counter'].to_i
      for n in 1..counter
        data = Hash.new
        
        data['click_con'] = params['click'].to_i.to_s
        data['keyword'] = '"'+params['keyword'].to_s+'"'
        data['time1'] = '"'+Time.now.to_s.split(' ')[0]+'"'
        data['gage'] = '"'+params['gage']+'"'
        data['url'] = '"'+params['url']+'"'
        if params['time2'].to_s == ''
          data['time2'] = '"' +(Time.now+(60*60*24*30)).to_s.split(' ')[0]+'"'
        else
          data['time2'] = '"'+params['time2'].to_s+'"'
        end
        #data['power'] = '1'
        data['user_id'] = '"'+params['user_id']+'"'
        q = "insert into board2(#{data.keys.join(',')}) values(#{data.values.join(',')})"
        puts q
        db.execute(q)
      end
      db.execute('delete from money where _id = '+params['db_id'].to_s)
      #send_text = "(플레이스 실소비자 유입 신청)  유저아이디 : #{session['user_id']} , 슬롯개수 : #{data['con']}"
      #http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text='+send_text)
      render json: {'result' => 1, 'message' => ''}
    rescue Exception => e
      puts e
      render json: {'result' => 0, 'message' => '실패'}
    end
  end
  
  def board2_admin
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      @db_id = params['id']
      @data = []
      r = db.query("select * from money where _id = #{@db_id}")
      r.each do |i|
        @data = i
      end
    else
      redirect_to '/'
    end
  end

  def board2_edit
    db = SQLite3::Database.open('./soonje.db')
    user_id = params['user_id']
    db_id = params['id']
    @db_id = db_id
    @user_id = user_id
    r = db.query('select * from board2 where _id = '+db_id.to_s+' and user_id = "'+user_id+'"')
    @data = []
    r.each do |i|
      @data = i
    end
  end

  def board2_edit_action
    db = SQLite3::Database.open('./soonje.db')
    db.execute('update board2 set click_con = "'+params['click']+'", keyword = "'+params['keyword']+'", gage="'+params['gage'].to_s+'", url="'+params['url'].to_s+'"  where _id = '+params['id'].to_s+' and user_id = "'+params['user_id'].to_s+'"')
    if session['power'] != 1
      send_text = "(플레이스 실소비자 유입 수정 요청) 슬롯아이디 : #{params['id']}  유저아이디 : #{params['user_id']} , 키워드 : #{params['keyword']} , 슬롯종료일 : #{params['time2']} , 상호명 : #{params['gage'].to_s} , url : #{params['url'].to_s}"
      http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text='+send_text)
    end
    render json: {'result' => 1}
  end

  def board2_action
    begin
      db = SQLite3::Database.open('./soonje.db')
      data = Hash.new
      data['con'] = params['click'].to_s
      data['keyword'] = '"'+params['keyword'].to_s+'"'
      data['url'] = '"'+params['place_url'].to_s+'"'
      data['gage'] = '"'+params['gage_sangho'].to_s+'"'
      #data['name'] = '"'+params['name'].to_s+'"'
      #data['time1'] = '"'+Time.now.to_s.split(' ')[0]+'"'
      #data['time2'] = '"'+params['time2'].to_s+'"'
      #data['power'] = '1'
      data['user_id'] = '"'+session['user_id']+'"'
      data['power'] = '0'
      q = "insert into money(#{data.keys.join(',')}) values(#{data.values.join(',')})"
      puts q
      db.execute(q)
      send_text = "(플레이스 실소비자 유입 신청)  유저아이디 : #{session['user_id']} , 슬롯개수 : #{data['con']}"
      http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text='+send_text)
      render json: {'result' => 1, 'message' => ''}
    rescue Exception => e
      puts e
      render json: {'result' => 0, 'message' => '실패'}
    end
  end

  def index
    @q = params['q'].to_s
    @page = params['page'].to_s
    if @page == ''
      @page = '1'
    end
    db = SQLite3::Database.open('./soonje.db')
    if session['power'] == 1
      if @q == ''
        r = db.query('select * from board1 limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      else
        r = db.query('select * from board1 where user_id = "'+@q+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
      end
    else
      r = db.query('select * from board1 where user_id = "'+session['user_id']+'" limit '+(@page.to_i*10-11).to_s+','+(@page.to_i*10).to_s)
    end
    @data = Array.new
    r.each do |i|
      time2 = i[5].split('-')
      time3 = Time.new(time2[0].to_i,time2[1].to_i,time2[2].to_i,0,0,0,"+09:00")-Time.now
      time4 = time3/(60*60*24)
      i << time4.to_i.to_s
      p i
      @data << i
    end
  end

  def add_user

  end

  def add_user_action
    db = SQLite3::Database.open('./soonje.db')
    user_id = params['user_id'].to_s
    user_pw = params['user_pw'].to_s
    power = -1.to_s
    memo = params['memo1'].to_s
    check = 1
    r = db.query('select * from user3 where user_id = "'+user_id+'"')
    r.each do |i|
      check = 0
    end
    if check == 0
      render json: {'result' => 0, 'message' => '중복아이디'}
    else
      if user_id == "" or user_pw == ''
        render json: {'result' => 0, 'message' => '실패'}
      else
        r = db.query('insert into user3(user_id,user_pw,power,memo) values("'+user_id+'","'+user_pw+'",'+power+',"'+memo+'")')
        render json: {'result' => 1, 'message' => '성공'}
      end
    end
  end

  def mail_setting
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      r = db.query('select * from admin_mail2')
      @email = ''
      r.each do |i|
        @email = i[1]
      end
    else
      redirect_to '/'
    end
  end

  def mail_update_action
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      db.query('update admin_mail2 set email = "'+params['mail']+'" where id = 1')
      render json: {'result' => 1}
    else
      render json: {'result' => 0}
    end
  end

  def board1_action
    begin
      db = SQLite3::Database.open('./soonje.db')
      data = Hash.new
      data['click_con'] = params['click'].to_s
      data['product'] = '"'+params['product'].to_s+'"'
      data['name'] = '"'+params['name'].to_s+'"'
      data['time1'] = '"'+Time.now.to_s.split(' ')[0]+'"'
      data['time2'] = '"'+params['time2'].to_s+'"'
      data['power'] = '1'
      data['user_id'] = '"'+session['user_id']+'"'
      q = "insert into board1(#{data.keys.join(',')}) values(#{data.values.join(',')})"
      puts q
      db.execute(q)
      send_text = "유저아이디 : #{session['user_id']} , 상품구분 : #{data['product']} , 상품명 : #{data['name']} , 슬롯종료일 : #{data['time2']}"
      http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text='+send_text)
      render json: {'result' => 1, 'message' => ''}
    rescue Exception => e
      puts e
      render json: {'result' => 0, 'message' => '실패'}
    end
  end

  def logout
    session.clear
  end

  def login
    if session['user_id'] == nil

    else
      redirect_to '/index'
    end
  end

  def login_action
    db = SQLite3::Database.open('./soonje.db')
    user_id = params['user_id']
    user_pw = params['user_pw']
    if user_id.to_s.split(' ').join("") == ''
      render json: {'result' => 0, 'message' => 'login 실패'}
    else
      result = db.query("select * from user3 where user_id = '#{user_id}' and user_pw = '#{user_pw}'")
      check = 0
      power = 2
      result.each do |i|
        check = 1
        power = i[3].to_i
      end

      if check == 1
        if power == -1
          render json: {'result' => 0, 'message' => '계정승인대기중'}
        else
          session['user_id'] = user_id
          session['power'] = power
          render json: {'result' => 1, 'message' => 'login 성공'}
        end
      else
        render json: {'result' => 0, 'message' => 'login 실패'}
      end
    end
  end
  
  #슬롯 연장신청 접수
  def add_time_action
    if session['power'] == 1
      db = SQLite3::Database.open('./soonje.db')
      db_id = params['id']
      time3 = params['time3']
      r = db.query('select time2 from board2 where _id = '+db_id.to_s)
      time2 = ''
      r.each do |i|
        time2 = i[0]
      end
      time22 = time2.split('-')
      time = (Time.new(time22[0].to_i,time22[1].to_i,time22[2].to_i,0,0,0,"+09:00")+(time3.to_i*60*60*24)).to_s.split(' ')[0]
      puts q = 'update board2 set time3 = 0 , time2 = "'+time+'" where _id = '+db_id.to_s
      db.query(q)
      redirect_to '/slot_list?q='+params['user_id'].to_s
    else
      redirect_to '/'
    end
  end
  
  #슬롯 연장신청
  def add_time
    if session['power'] > 0
      db = SQLite3::Database.open('./soonje.db')
      add_time = params['add_time']
      db_id = params['id']
      db.query('update board2 set time3 = '+add_time.to_s+' where _id = '+db_id.to_s)
      if session['power'] != 1
        send_text = "(플레이스 실소비자 연장 요청) 슬롯아이디 : #{params['id']}  유저아이디 : #{params['user_id']}  연장일 : #{params['add_time']}"
        http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text='+send_text)
      end
      render json: {'result' => 1}
    else
      render json: {'result' => 0}
    end
  end
end
