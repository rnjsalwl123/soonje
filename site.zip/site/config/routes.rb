Rails.application.routes.draw do
  get '/' => 'home#login'
  get '/index' => 'home#index'
  get '/page_up1' => 'home#page_up1'
  post '/login_action' => 'home#login_action'
  get '/logout' => 'home#logout'
  get '/board1up' => 'home#board1up'
  post '/board1_action' => 'home#board1_action'
  get '/mail_setting' => 'home#mail_setting'
  post '/mail_update_action' => 'home#mail_update_action'
  get '/add_user' => 'home#add_user'
  post '/add_user_action' => 'home#add_user_action'
  get '/index2' => 'home#index2'
  get '/board2up' => 'home#board2up'
  post '/board2_action' => 'home#board2_action'
  get '/board2_edit' => 'home#board2_edit'
  post '/board2_edit_action' => 'home#board2_edit_action'
  get '/index2_add' => 'home#index2_add'
  get '/board2_admin' => 'home#board2_admin'
  post '/index2_add_action' => 'home#index2_add_action'
  get '/user_list' => 'home#user_list'
  get '/slot_list' => 'home#slot_list'
  get '/board2_delete' => 'home#board2_delete'
  post '/add_time' => 'home#add_time'
  get '/add_time_action' => 'home#add_time_action'
  get '/user2_list' => 'home#user2_list'
  get '/user2_list_action' => 'home#user2_list_action'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
