require 'sqlite3'
require 'http'

db = SQLite3::Database.open('./soonje.db')
#db.execute('create table user3 (_id integer primar key autoincrement,user_id varchar(100), user_pw varchar(100), power int, memo varchar(100))')
#db.execute('insert into user2 (user_id,user_pw,power) values("test","1234",2)')
#db.execute('update user2 set _id = 2 where user_id = "test"')
#db.execute('create table board1(_id integer primary key autoincrement, click_con int, product varchar(100), name varchar(100), time1 varchar(100), time2 varchar(100))')
# db.execute('insert into user3(user_id,user_pw,power) values("admin","1345",1)')
# db.execute('insert into user3(user_id,user_pw,power) values("test","1234",2)')
#db.execute('alter table board1 add power int not null')
#db.execute('alter table board1 add user_id varchar(100)')
#db.execute('create table admin_mail2 (id int,email varchar(100))')
#db.execute('insert into admin_mail2(id,email) values(1, "lmkok123@naver.com")')
# r = db.query('select * from admin_mail2')
#db.execute('create table board2(_id integer primary key autoincrement,user_id varchar(100),click_con int,keyword varchar(100),time1 varchar(100),time2 varchar(100))')
# r.each do |i|
#     p i
# end
#db.execute('create table money(_id integer primary key autoincrement, user_id varchar(100), con int, power int)')
#db.execute('alter table board2 add time3 int')
db.execute('alter table board2 add gage varchar(100)')

#http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/getUpdates')
# http = HTTP.get('https://api.telegram.org/bot5418957819:AAFuZtpOFImJOkQFC9beCuGmZDqaP4U56M4/sendMessage?chat_id=-639627325&text=test입니다')
# puts http.to_s