#!/usr/bin/env bash
ruby start.rb